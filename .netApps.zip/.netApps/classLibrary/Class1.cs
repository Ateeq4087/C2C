﻿namespace classLibrary;

public class Class1
{

}
